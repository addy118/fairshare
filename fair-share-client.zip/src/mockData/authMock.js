const token = {
  accessToken:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwibmFtZSI6Ikhlcm1pb25lIiwidXNlcm5hbWUiOiJoZXJtaW9uZSIsImVtYWlsIjoiaGVybWlvbmVAaG9nd2FydHMuZWR1IiwicGhvbmUiOiIrOTE5OTk5OTk5OTExIiwiaWF0IjoxNzQ0MTc3MjMyLCJleHAiOjE3NDQxNzc4MzJ9.Bjt5chZF_5I0QFu8X1Y2L69Iyl0Lxb7LRFu1ezh8tDw",
  user: {
    id: 2,
    name: "Hermione",
    username: "hermione",
    email: "hermione@hogwarts.edu",
    phone: "+919999999911",
    iat: 1744177232,
    exp: 1744177832,
  },
};

const login = {
  msg: "Login Successful!",
  accessToken:
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwibmFtZSI6Ikhlcm1pb25lIiwidXNlcm5hbWUiOiJoZXJtaW9uZSIsImVtYWlsIjoiaGVybWlvbmVAaG9nd2FydHMuZWR1IiwicGhvbmUiOiIrOTE5OTk5OTk5OTExIiwiaWF0IjoxNzQ0MTc4MTM4LCJleHAiOjE3NDQxNzg3Mzh9.Vfqfiypr18nPCqh5zGFs7ion4nKhoEWqAakqLUYHYJc",
  user: {
    id: 2,
    name: "Hermione",
    username: "hermione",
    email: "hermione@hogwarts.edu",
    phone: "+919999999911",
    iat: 1744178138,
    exp: 1744178738,
  },
};
